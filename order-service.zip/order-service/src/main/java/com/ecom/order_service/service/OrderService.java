package com.ecom.order_service.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.ecom.order_service.dto.OrderItemRequestDto;
import com.ecom.order_service.dto.OrderRequestDto;
import com.ecom.order_service.dto.OrderResponseDto;
import com.ecom.order_service.dto.OrderStatus;
import com.ecom.order_service.dto.ProductResponseDto;
import com.ecom.order_service.entity.OrderItems;
import com.ecom.order_service.entity.Orders;
import com.ecom.order_service.repository.OrderItemsRepository;
import com.ecom.order_service.repository.OrderRepository;

import jakarta.persistence.criteria.Order;

@Service
public class OrderService {

	private OrderRepository orderRepository;
	private OrderItemsRepository orderItemsRepository;
	private ProductClient productClient;
	
	public OrderService(OrderRepository orderRepository ,OrderItemsRepository orderItemsRepository,ProductClient productClient){
		this.orderRepository = orderRepository;
		this.orderItemsRepository = orderItemsRepository;
		this.productClient = productClient;
	}
	
	public OrderResponseDto placeOrder(OrderRequestDto dto) {
		
		String orderId = generateOrderId();
		double totalAmount = 0.0;
		List<OrderItems> orderItemsList = new ArrayList<OrderItems>();
		for(OrderItemRequestDto itemDto: dto.getItems()) {
			ProductResponseDto product = productClient.getProductName(itemDto.getProductId());
			if(itemDto.getQuantity() > product.getStockQuantity()) {
				throw new RuntimeException("Insufficient stock for product: " + product.getName());
			}
			productClient.updateStock(itemDto.getProductId(), -itemDto.getQuantity());
			double itemTotal = itemDto.getQuantity() * product.getPrice();
			totalAmount += itemTotal;
			
			OrderItems orderItems = new OrderItems( generateOrderItemId(), orderId, itemDto.getProductId() , itemDto.getQuantity() ,product.getPrice());
			orderItemsList.add(orderItems);
		}
		Orders order = new Orders(orderId, dto.getCustomerId(),LocalDateTime.now(),totalAmount,OrderStatus.PENDING);
		orderRepository.save(order);
		orderItemsRepository.saveAll(orderItemsList);
		return new OrderResponseDto(order.getOrderID(), order.getCustomerId(), order.getOrderDate(), order.getTotalAmount(), order.getStatus(), orderItemsList);
	}
	
	public OrderResponseDto getOrderById(String orderId) {
		Orders order = orderRepository.findById(orderId)
				.orElseThrow(()-> new RuntimeException("Order not found with id:-"+orderId));
		List<OrderItems> items = orderItemsRepository.findByOrderId(orderId);
		return new OrderResponseDto(order.getOrderID(), order.getCustomerId(), order.getOrderDate(), order.getTotalAmount(), order.getStatus(), items);
	}
	
	
	  public List<OrderResponseDto> getOrdersByCustomerId(String customerId){
	  List<Orders> orders = orderRepository.findByCustomerId(customerId); 
	  List<OrderResponseDto> responseList = new ArrayList<>();
	  for(Orders orderObj : orders) {
		  List<OrderItems> items = orderItemsRepository.findByOrderId(orderObj.getOrderID());
		  responseList.add(new OrderResponseDto(orderObj.getOrderID(), orderObj.getCustomerId(),orderObj.getOrderDate(), orderObj.getTotalAmount(),orderObj.getStatus(),items));
	  }
	  return responseList;
	  }
	 
	  public void updateOrderStatus(String orderId , OrderStatus orderStatus) {
		  
		  Orders order = orderRepository.findById(orderId).orElseThrow(()-> new RuntimeException("Order not found with id: "+ orderId));
		  order.setStatus(orderStatus);
		  orderRepository.save(order);
		  
	  }
	private String generateOrderId() {
		return "ord-" +UUID.randomUUID().toString().substring(0,8);
	}
	
	private String generateOrderItemId() {
		return "item-" +UUID.randomUUID().toString().substring(0,8);
	}
}
