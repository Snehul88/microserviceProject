package com.ecom.order_service.dto;

import lombok.Data;

@Data
public class ProductResponseDto {

	private String productId;
	private String name;
	//private String description;
	private Double price;
	//private String category;
	private int stockQuantity;
	//private String imageUrl;
	//private boolean available;
}
