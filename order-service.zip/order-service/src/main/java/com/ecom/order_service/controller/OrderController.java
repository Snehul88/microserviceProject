package com.ecom.order_service.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.order_service.dto.OrderRequestDto;
import com.ecom.order_service.dto.OrderResponseDto;
import com.ecom.order_service.dto.OrderStatus;
import com.ecom.order_service.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {

	private final OrderService orderService;
	
	public OrderController(OrderService orderService) {
		this.orderService = orderService;
	}
	
	@PostMapping()
	public ResponseEntity<?> createOrder(@RequestBody OrderRequestDto req){
		OrderResponseDto response = orderService.placeOrder(req);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/{orderId}")
	public ResponseEntity<OrderResponseDto> getOrderById(@PathVariable String orderId){
		OrderResponseDto response = orderService.getOrderById(orderId);
		return ResponseEntity.ok(response);
	} 
	
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<?> getOrderByCustomerId(@PathVariable String customerId){
		 return ResponseEntity.ok(orderService.getOrdersByCustomerId(customerId));
	}
	
	@PatchMapping("/{orderId}/status")
	public ResponseEntity<?> updateOrderStatus(@PathVariable String orderId,@RequestBody OrderStatus status){
		orderService.updateOrderStatus(orderId, status);
		return ResponseEntity.ok("Order status updated...");
	}
}
