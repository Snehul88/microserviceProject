package com.ecom.order_service.dto;

public enum OrderStatus {

	PENDING,
	CONFIRMED,
	SHIPPED,
	DELIVERED,
	CANCELED,
	RETURNED
}
