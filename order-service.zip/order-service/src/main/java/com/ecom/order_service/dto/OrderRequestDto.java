package com.ecom.order_service.dto;

import java.util.List;

import lombok.Data;

@Data
public class OrderRequestDto {

	private String customerId;
	private List<OrderItemRequestDto> items; 
}
