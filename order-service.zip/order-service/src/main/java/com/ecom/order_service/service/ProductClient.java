package com.ecom.order_service.service;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ecom.order_service.dto.ProductResponseDto;

@Component
public class ProductClient {
	
	private final RestTemplate restTemplate;
	public ProductClient(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	public ProductResponseDto getProductName(String productId) {
		String url = "http://localhost:6000/products/"+ productId;
		return restTemplate.getForObject(url, ProductResponseDto.class);
	}
	
	public void updateStock(String productId, int quantity) {
		String url = "http://localhost:6000/products/"+ productId +"/stock?stockQuantity=" + quantity;
		restTemplate.patchForObject(url, null, Void.class);
	}
}
