package com.ecom.apigateway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackCircuitController {

	@GetMapping("/fallback/orders")
    public ResponseEntity<String> orderFallback() {
        return ResponseEntity.ok("Order Service is temporarily unavailable. Please try again later.");
    }
}
