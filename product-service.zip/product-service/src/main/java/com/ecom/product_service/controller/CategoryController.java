package com.ecom.product_service.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.product_service.dto.CategoryRequestDto;
import com.ecom.product_service.dto.CategoryResponseDto;
import com.ecom.product_service.dto.ExtendedCategoryResponseDto;
import com.ecom.product_service.service.CategoryService;

@RestController
@RequestMapping("/categories")
public class CategoryController {
	
	private CategoryService categoryService;
	
	public CategoryController(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	
	@PostMapping
	public CategoryResponseDto createCategory(@RequestBody CategoryRequestDto categoryRequestDto) {
		return categoryService.createCategory(categoryRequestDto);
	}
	
	@GetMapping
	public List<ExtendedCategoryResponseDto> getAllCategory(){
		return categoryService.getAllCategory();
	}
	
	@GetMapping("/{categoryId}")
	public ExtendedCategoryResponseDto getAllCategoryById(@PathVariable String categoryId){
		return categoryService.getCategoryById(categoryId);
	}
}
