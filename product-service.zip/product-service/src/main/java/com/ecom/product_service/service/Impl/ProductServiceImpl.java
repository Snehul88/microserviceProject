package com.ecom.product_service.service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecom.product_service.dto.ProductRequestDto;
import com.ecom.product_service.dto.ProductResponseDto;
import com.ecom.product_service.entity.Category;
import com.ecom.product_service.entity.Product;
import com.ecom.product_service.repository.CategoryRepository;
import com.ecom.product_service.repository.ProductRepository;
import com.ecom.product_service.service.ProductService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService{

	private final ProductRepository productRepository;
	
	private final CategoryRepository categoryRepository;
	
	
	@Override
	public ProductResponseDto createProduct(ProductRequestDto productRequestDto) {
		Category category = categoryRepository.findById(productRequestDto.getCategoryId())
				.orElseThrow(()-> new RuntimeException("category not found"));
		Product product = new Product();
		product.setName(productRequestDto.getName());
		product.setDescription(productRequestDto.getDescription());
		product.setPrice(productRequestDto.getPrice());
		product.setStockQuantity(productRequestDto.getStockQuantity());
		product.setCategory(category);
		
		Product saveProduct = productRepository.save(product);
		ProductResponseDto prod = setProductToDto(saveProduct);
		return prod;
	}

	@Override
	public ProductResponseDto getProductById(String productId) {
		Product product = productRepository.findById(productId)
				.orElseThrow(()-> new RuntimeException("Product not found"));
		return setProductToDto(product);
	}

	@Override
	public List<ProductResponseDto> allProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll().stream().map(this::setProductToDto).toList();
	}

	@Override
	public ProductResponseDto updateStock(String productId, Integer stockQuantity) {
		Product product = productRepository.findById(productId)
				.orElseThrow(()-> new RuntimeException("Product not found"));
		product.setStockQuantity(product.getStockQuantity() + stockQuantity);
		productRepository.save(product);
		return setProductToDto(product);
	}
	private ProductResponseDto setProductToDto(Product product) {
		ProductResponseDto productDto = new ProductResponseDto();
		productDto.setProductId(product.getProductId());
		productDto.setName(product.getName());
		productDto.setDescription(product.getDescription());
		productDto.setPrice(product.getPrice());
		productDto.setStockQuantity(product.getStockQuantity());
		productDto.setCategoryName(product.getCategory().getName());
		productDto.setInStock(product.getInStock());
		return productDto;
		
	}
}
