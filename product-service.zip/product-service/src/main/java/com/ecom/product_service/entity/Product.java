package com.ecom.product_service.entity;

import java.time.LocalDateTime;

import com.ecom.product_service.config.IdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Getter@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Product {
	
	@Id
	private String productId;
	private String name;
	private String description;
	private Double price;
	private Integer stockQuantity;
	private Boolean inStock;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;
	
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category category;
	
	@PrePersist
	@PreUpdate
	public void updateStockStatus() {
		this.inStock = this.stockQuantity !=null && this.stockQuantity > 0;
		if(createdAt == null) createdAt = LocalDateTime.now();
		updatedAt = LocalDateTime.now();
		
		if(this.productId == null) {
			this.productId = "prod-"+ String.format("%05d", IdGenerator.generateProductId());
		}
	}
}
