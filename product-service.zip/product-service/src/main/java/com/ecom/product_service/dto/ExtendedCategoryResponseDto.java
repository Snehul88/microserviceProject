package com.ecom.product_service.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ExtendedCategoryResponseDto extends CategoryResponseDto{
	List<ProductResponseDto> extendedProducts;
	
	public ExtendedCategoryResponseDto(String categoryId , String name, String description, List<ProductResponseDto> extendedProducts) {
		super(categoryId,name ,description);
		this.extendedProducts = extendedProducts;
	}
}
