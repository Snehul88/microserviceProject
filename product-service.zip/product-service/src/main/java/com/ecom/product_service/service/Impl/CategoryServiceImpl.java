package com.ecom.product_service.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ecom.product_service.dto.CategoryRequestDto;
import com.ecom.product_service.dto.CategoryResponseDto;
import com.ecom.product_service.dto.ExtendedCategoryResponseDto;
import com.ecom.product_service.dto.ProductResponseDto;
import com.ecom.product_service.entity.Category;
import com.ecom.product_service.entity.Product;
import com.ecom.product_service.mapper.CategoryMapping;
import com.ecom.product_service.mapper.ProductMapping;
import com.ecom.product_service.repository.CategoryRepository;
import com.ecom.product_service.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{

	private final CategoryRepository categoryRepository;
	
	public CategoryServiceImpl(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
		
	}
	
	@Override
	public CategoryResponseDto createCategory(CategoryRequestDto categoryRequestDto) {

		Category category = new Category();
		category.setName(categoryRequestDto.getName());
		category.setDescription(categoryRequestDto.getDescription());
		Category categorySaved = categoryRepository.save(category);
		return CategoryMapping.toCategoryResponseDto(categorySaved);
	}

	@Override
	public ExtendedCategoryResponseDto getCategoryById(String categoryId) {
		Category category = categoryRepository.findById(categoryId).
				orElseThrow(()->new RuntimeException("category not found"));
		return convertToExtendedResponseDto(category);
	}

	@Override
	public List<ExtendedCategoryResponseDto> getAllCategory() {
		List<Category> category = categoryRepository.findAll();
		List<ExtendedCategoryResponseDto> categoryResponseDtos = new ArrayList<>();
		for(Category categor: category) {
			ExtendedCategoryResponseDto categoryResponseDto = convertToExtendedResponseDto(categor);
			categoryResponseDtos.add(categoryResponseDto);
		}
		return categoryResponseDtos;
	}

	private ExtendedCategoryResponseDto convertToExtendedResponseDto(Category categor) {

		List<Product> productList = new ArrayList<>();
		return new ExtendedCategoryResponseDto(categor.getCategoryId(),categor.getName(),categor.getDescription(),
				productList.stream().map(ProductMapping::toProductResponseDto).toList());
	}

	@Override
	public CategoryResponseDto updateCategory(String categoryId, CategoryRequestDto categoryRequestDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCategory(String categoryId) {
		// TODO Auto-generated method stub
		
	}

}
