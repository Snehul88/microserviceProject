package com.ecom.product_service.service;

import java.util.List;

import com.ecom.product_service.dto.CategoryRequestDto;
import com.ecom.product_service.dto.CategoryResponseDto;
import com.ecom.product_service.dto.ExtendedCategoryResponseDto;

public interface CategoryService {
	
	CategoryResponseDto createCategory(CategoryRequestDto categoryRequestDto);
	ExtendedCategoryResponseDto getCategoryById(String categoryId);
	List<ExtendedCategoryResponseDto> getAllCategory();
	CategoryResponseDto updateCategory(String categoryId,CategoryRequestDto categoryRequestDto);
	void deleteCategory(String categoryId);
}
