package com.ecom.product_service.mapper;

import com.ecom.product_service.dto.CategoryResponseDto;
import com.ecom.product_service.entity.Category;

public class CategoryMapping {
	
	public static CategoryResponseDto toCategoryResponseDto(Category category) {
		CategoryResponseDto categoryResponseDto = new CategoryResponseDto();
		categoryResponseDto.setName(category.getName());
		categoryResponseDto.setDescription(category.getDescription());
		categoryResponseDto.setCategoryId(category.getCategoryId());
		return categoryResponseDto;
	}
	
	public static Category toCategoryEntity(CategoryResponseDto categoryResponseDto) {
		Category category = new Category();
		category.setName(categoryResponseDto.getName());
		category.setDescription(categoryResponseDto.getDescription());
		category.setCategoryId(categoryResponseDto.getCategoryId());
		return category;
	}

}
