package com.ecom.product_service.service;

import java.util.List;

import com.ecom.product_service.dto.ProductRequestDto;
import com.ecom.product_service.dto.ProductResponseDto;

public interface ProductService {
	
	ProductResponseDto createProduct(ProductRequestDto productRequestDto);
	ProductResponseDto getProductById(String productId);
	List<ProductResponseDto> allProducts();
	ProductResponseDto updateStock(String productId,Integer stockQuantity);
}
