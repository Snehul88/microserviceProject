package com.ecom.product_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.product_service.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, String>{

}
