package com.ecom.payment_service.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.payment_service.dto.PaymentRequestDto;
import com.ecom.payment_service.dto.PaymentResponseDto;
import com.ecom.payment_service.service.PaymentService;

@RestController
@RequestMapping("/payments")
public class PaymentController {
	
	private PaymentService paymentService;
	
	public PaymentController(PaymentService paymentService) {
		this.paymentService = paymentService;
	}

	@PostMapping
	public ResponseEntity<PaymentResponseDto> processPayment(PaymentRequestDto dto){
		return ResponseEntity.ok(paymentService.processPayment(dto));
	}
	
	@GetMapping("/order/{orderId}")
	public ResponseEntity<PaymentResponseDto> getPaymentDetails(String orderId){
		PaymentResponseDto responseDto = paymentService.getPaymentByOrderId(orderId);
		if(responseDto !=null) {
			return ResponseEntity.ok(responseDto);
			
		}else {
			ResponseEntity.notFound().build();
		}
		return null;
	}
}
