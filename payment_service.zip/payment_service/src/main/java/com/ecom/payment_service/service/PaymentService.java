package com.ecom.payment_service.service;

import java.time.LocalDate;
import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.ecom.payment_service.dto.PaymentRequestDto;
import com.ecom.payment_service.dto.PaymentResponseDto;
import com.ecom.payment_service.dto.PaymentStatus;
import com.ecom.payment_service.entity.Payment;
import com.ecom.payment_service.repository.PaymentRepository;

@Service
public class PaymentService {
	
	private PaymentRepository paymentRepository;
	private OrderClient client;
	
	public PaymentService(PaymentRepository paymentRepository, OrderClient client) {
		this.paymentRepository = paymentRepository;
		this.client = client;
				
	}
	
	public PaymentResponseDto processPayment(PaymentRequestDto dto) {
		
		String paymentId = generatePaymentId();
		Payment payment = new Payment();
		payment.setPaymentId(paymentId);
		payment.setOrderId(dto.getOrderId());
		payment.setAmount(dto.getAmount());
		payment.setPaymentDate(LocalDate.now());
		boolean paymentSuccess = new Random().nextBoolean();
		if(paymentSuccess){
			payment.setPaymentStatus(PaymentStatus.SUCCESS);
			payment.setTransactionId(UUID.randomUUID().toString());
			client.updateOrderStatus(dto.getPaymentId(), "CONFIRMED");
		}else {
			payment.setPaymentStatus(PaymentStatus.FAILED);
			payment.setTransactionId("N/A");
			client.updateOrderStatus(dto.getPaymentId(), "FAILED");
		}
		paymentRepository.save(payment);
		PaymentResponseDto response = new PaymentResponseDto();
		response.setPaymentId(paymentId);
		response.setOrderId(payment.getOrderId());
		response.setAmount(payment.getAmount());
		response.setPaymentStatus(payment.getPaymentStatus());
		response.setTransactionId(payment.getTransactionId());
		return response;
	}
	private String generatePaymentId() {
		return "pay-" + UUID.randomUUID().toString().substring(0,8);
	}

	public PaymentResponseDto getPaymentByOrderId(String orderId) {
		Payment payment = paymentRepository.findByOrderId(orderId);
		if(payment == null) {
			return null;
		}
		PaymentResponseDto dto = new PaymentResponseDto();
		dto.setPaymentId(payment.getPaymentId());
		dto.setOrderId(payment.getOrderId());
		dto.setAmount(payment.getAmount());
		dto.setPaymentStatus(payment.getPaymentStatus());
		dto.setTransactionId(payment.getTransactionId());
		return dto;
	}
}
