package com.ecom.payment_service.entity;

import java.time.LocalDate;

import com.ecom.payment_service.dto.PaymentStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment {

	@Id
	private String paymentId;
	private String orderId;
	private String customerId;
	private String amount;
	private LocalDate paymentDate;
	private PaymentStatus paymentStatus;
	private String transactionId;
}
