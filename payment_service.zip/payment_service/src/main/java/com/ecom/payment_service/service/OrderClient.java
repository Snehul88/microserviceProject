package com.ecom.payment_service.service;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ecom.payment_service.dto.OrderStatusUpdateRequestDto;

@Component
public class OrderClient {
	
	private final RestTemplate restTemplate;
	
	public OrderClient(RestTemplateBuilder builder) {
		this.restTemplate = builder.build();
	}

	public void updateOrderStatus(String orderId, String status) {
		String url ="http://localhost:6001/orders/" + orderId + "/status?status"+ status;
		OrderStatusUpdateRequestDto requestDto = new OrderStatusUpdateRequestDto();
		restTemplate.postForObject(url, requestDto, Void.class);
	}
}
