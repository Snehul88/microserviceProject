package com.ecom.payment_service.dto;

public enum PaymentStatus {

	PENDING,
	SUCCESS,
	FAILED
}
